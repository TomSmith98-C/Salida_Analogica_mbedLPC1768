/*
    Created by Tom Smith 
    April 14 2020
*/
#include "mbed.h"

AnalogOut Led(p20);
int i; 
Serial pc(USBTX,USBRX);
int main() 
{
    pc.printf("Salida Analogica");
    
    while(1) 
    {
        for (i=0; i<=1023; i+=10)
        {     
            Led = i;
            pc.printf("La unidad enviada al motor es de:");
            pc.printf("%f" + i);
            pc.printf("\n");
            wait(0.5);
                        
            Led = 0;
            pc.printf("Motor apagado");
            wait(0.5);
        }
    }
}
